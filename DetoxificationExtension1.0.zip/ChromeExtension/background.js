let detoxLog = [];
let detectedLog = [];
const connectedPorts = new Map();

const CONFIG = {
  API_BASE: "https://TechKid0109-Detox-Extension.hf.space",
  TOXIC_CONFIDENCE_THRESHOLD: 98,
  MAX_RETRIES: 4,
  LOG_CAP: 500,
  DETOX_CONCURRENCY: 4,
  CACHE_WRITE_INTERVAL_MS: 5000
};

// In-memory caches to reduce duplicate API calls for identical texts
const classificationCache = new Map(); // key -> { ts, result }
const detoxCache = new Map(); // key -> { ts, output }
let CACHE_TTL_MS = 1000 * 60 * 60; // 1 hour (mutable)
// Throttled persistence state for caches
let cachesDirty = { classification: false, detox: false };
let cacheFlushTimer = null;

function scheduleCachePersist() {
  if (cacheFlushTimer) clearTimeout(cacheFlushTimer);
  cacheFlushTimer = setTimeout(flushCachesToStorage, CONFIG.CACHE_WRITE_INTERVAL_MS || 5000);
}

async function flushCachesToStorage() {
  if (cacheFlushTimer) { clearTimeout(cacheFlushTimer); cacheFlushTimer = null; }
  const payload = {};
  try {
    if (cachesDirty.classification) {
      const serialized = {};
      classificationCache.forEach((v, k) => { serialized[k] = v; });
      payload.classificationCache = serialized;
      cachesDirty.classification = false;
    }
    if (cachesDirty.detox) {
      const serialized = {};
      detoxCache.forEach((v, k) => { serialized[k] = v; });
      payload.detoxCache = serialized;
      cachesDirty.detox = false;
    }
    if (Object.keys(payload).length > 0) {
      await storageSet(payload);
    }
  } catch (e) {
    // ignore persistence errors for now
    console.warn('Failed to flush caches to storage', e);
  }
}

function markCacheDirty(kind) {
  if (kind === 'classification') cachesDirty.classification = true;
  if (kind === 'detox') cachesDirty.detox = true;
  scheduleCachePersist();
}

// Delay helper
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));

// storage helpers
function storageGet(keys) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(keys, (res) => resolve(res || {}));
    } catch (e) {
      resolve({});
    }
  });
}

function storageSet(obj) {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.set(obj, () => resolve());
    } catch (e) {
      resolve();
    }
  });
}

// Warm up caches from storage at startup
(async function warmupCaches() {
  try {
    const stored = await storageGet(['classificationCache', 'detoxCache']);
    if (stored.classificationCache) {
      Object.entries(stored.classificationCache).forEach(([k, v]) => {
        try { classificationCache.set(k, v); } catch (e) {}
      });
    }
    if (stored.detoxCache) {
      Object.entries(stored.detoxCache).forEach(([k, v]) => {
        try { detoxCache.set(k, v); } catch (e) {}
      });
    }
  } catch (e) {
    /* ignore */
  }
})();

// Load extension settings and apply to runtime CONFIG
(async function applyStoredSettings(){
  try{
    const s = await storageGet(['extSettings']);
    const st = s.extSettings || {};
    if (st.TOXIC_CONFIDENCE_THRESHOLD != null) CONFIG.TOXIC_CONFIDENCE_THRESHOLD = Number(st.TOXIC_CONFIDENCE_THRESHOLD);
    if (st.DETOX_CONCURRENCY != null) CONFIG.DETOX_CONCURRENCY = Number(st.DETOX_CONCURRENCY);
    if (st.LOG_CAP != null) CONFIG.LOG_CAP = Number(st.LOG_CAP);
    if (st.CACHE_TTL_MINUTES != null) {
      const mins = Number(st.CACHE_TTL_MINUTES);
      if (!Number.isNaN(mins)) {
        CACHE_TTL_MS = mins * 60 * 1000;
      }
    }
  }catch(e){}
})();

// React to settings changes in storage
try{
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if (changes.extSettings && changes.extSettings.newValue) {
      const st = changes.extSettings.newValue;
      if (st.TOXIC_CONFIDENCE_THRESHOLD != null) CONFIG.TOXIC_CONFIDENCE_THRESHOLD = Number(st.TOXIC_CONFIDENCE_THRESHOLD);
      if (st.DETOX_CONCURRENCY != null) CONFIG.DETOX_CONCURRENCY = Number(st.DETOX_CONCURRENCY);
      if (st.LOG_CAP != null) CONFIG.LOG_CAP = Number(st.LOG_CAP);
      if (st.CACHE_TTL_MINUTES != null) {
        const mins = Number(st.CACHE_TTL_MINUTES);
        if (!Number.isNaN(mins)) {
          CACHE_TTL_MS = mins * 60 * 1000;
        }
      }
    }
  });
} catch(e) {}

// Push with cap
function pushWithCap(log, entry, cap = CONFIG.LOG_CAP) {
  log.push(entry);
  if (log.length > cap) log.shift();
}

// Exponential retry
async function fetchWithRetry(url, options, maxAttempts = CONFIG.MAX_RETRIES) {
  const baseDelay = 1000;
  let lastError = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) {
        lastError = new Error(`HTTP ${res.status}`);
        if (attempt < maxAttempts && (res.status === 429 || res.status >= 500)) {
          const delay = baseDelay * Math.pow(2, attempt - 1);
          await wait(delay + Math.floor(Math.random() * 100));
          continue;
        }
        return { success: false, error: String(lastError), attempts: attempt };
      }
      const json = await res.json();
      return { success: true, json, attempts: attempt };
    } catch (err) {
      lastError = err;
      if (attempt < maxAttempts) {
        const delay = baseDelay * Math.pow(2, attempt - 1);
        await wait(delay + Math.floor(Math.random() * 100));
        continue;
      }
      return { success: false, error: String(lastError), attempts: attempt };
    }
  }
  return { success: false, error: String(lastError), attempts: maxAttempts };
}

async function classifyText(text) {
  try {
    const key = String(text).slice(0, 5000);
    const now = Date.now();
    const cached = classificationCache.get(key);
    if (cached && now - cached.ts < CACHE_TTL_MS) {
      console.log(`[classify] CACHE HIT: isToxic=${cached.result.isToxic}`);
      return Object.assign({}, cached.result, { cached: true });
    }

    const res = await fetchWithRetry(`${CONFIG.API_BASE}/classify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });

    if (!res.success) {
      return { success: false, error: res.error, attempts: res.attempts };
    }

    const data = res.json;
    const conf = data?.confidence || {};
    
    // Support both old format (LABEL_0/LABEL_1) and new format (non-toxic/toxic)
    const label0Confidence = conf.LABEL_0 ?? conf['non-toxic'] ?? 0;
    let toxicConfidence = conf.LABEL_1 ?? conf.toxic ?? 0;
    const classification = data.classification;
    
    // Convert to percentage for consistent comparison
    const toxicPercentage = toxicConfidence * 100;
    
    // Normalize classification to "toxic" or "non-toxic"
    const isToxic =
      (classification === "toxic" || classification === "LABEL_1") &&
      toxicPercentage >= CONFIG.TOXIC_CONFIDENCE_THRESHOLD;

    // Debug logging
    console.log(`[classify] text="${String(text).slice(0, 50)}..." classification=${classification} toxic=${toxicPercentage.toFixed(2)}% threshold=${CONFIG.TOXIC_CONFIDENCE_THRESHOLD}% isToxic=${isToxic}`);

    const result = {
      success: true,
      classification: data.classification,
      isToxic,
      confidence: { label0: label0Confidence, label1: toxicConfidence },
      toxicPercentage,
      attempts: res.attempts
    };

    try {
      classificationCache.set(key, { ts: Date.now(), result });
      markCacheDirty('classification');
    } catch (e) {}

    return result;
  } catch (err) {
    console.error("Classification error:", err);
    return { success: false, error: String(err), attempts: 0 };
  }
}

async function detoxifyTextSingle(text) {
  const key = String(text).slice(0, 5000);
  const now = Date.now();
  const cached = detoxCache.get(key);
  if (cached && now - cached.ts < CACHE_TTL_MS) {
    return { output: cached.output, attempts: 0, error: null, cached: true };
  }

  const classification = await classifyText(text);
  if (!(classification.success && classification.isToxic)) {
    // cache that detox is not needed
    try {
      detoxCache.set(key, { ts: Date.now(), output: text });
      markCacheDirty('detox');
    } catch (e) {}
    return {
      output: text,
      attempts: classification.attempts,
      error: classification.success ? null : classification.error
    };
  }

  const r = await fetchWithRetry(`${CONFIG.API_BASE}/detoxify`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ text })
  });

  if (!r.success) {
    return { output: text, attempts: r.attempts, error: r.error };
  }

  const json = r.json || {};
  // Support both old format and new format
  let output = text;
  if (Array.isArray(json.detoxified) && json.detoxified.length > 0) {
    output = json.detoxified[0];
  } else if (json.detoxified) {
    output = json.detoxified;
  } else if (Array.isArray(json.data) && json.data.length > 0) {
    output = json.data[0];
  } else if (Array.isArray(json.output) && json.output.length > 0) {
    output = json.output[0];
  }

  try { detoxCache.set(key, { ts: Date.now(), output });
    markCacheDirty('detox');
  } catch (e) {}
  return { output, attempts: r.attempts, error: null };
}

async function detoxifyTextBatch(texts) {
  // Run detox operations with limited concurrency to speed up throughput
  const tasks = texts.map((t) => {
    return async () => {
      const capped = typeof t === "string" && t.length > 5000 ? t.slice(0, 5000) : t;
      return detoxifyTextSingle(capped);
    };
  });

  const concurrency = CONFIG.DETOX_CONCURRENCY || 4;
  const results = new Array(tasks.length);
  let idx = 0;

  const workers = new Array(concurrency).fill(0).map(async () => {
    while (true) {
      const i = idx++;
      if (i >= tasks.length) break;
      try {
        results[i] = await tasks[i]();
      } catch (e) {
        results[i] = { output: texts[i], attempts: 0, error: String(e) };
      }
    }
  });

  await Promise.all(workers);
  return results;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.type) {
    case "logDetox":
      {
        const entry = Object.assign({}, msg.payload || {});
        if (sender && sender.tab) {
          entry.tabId = sender.tab.id;
          entry.pageUrl = sender.tab.url;
        }
        pushWithCap(detoxLog, entry);
      }
      break;

    case "logDetected":
      {
        const entry = Object.assign({}, msg.payload || {});
        if (sender && sender.tab) {
          entry.tabId = sender.tab.id;
          entry.pageUrl = sender.tab.url;
        }
        pushWithCap(detectedLog, entry);
      }
      break;

    case "getDetoxLog":
      sendResponse({
        pairs: detoxLog.map(e => ({
          id: e.id ?? null,
          original: e.original,
          detoxified: e.detoxified,
          blocked: e.blocked === true,
          attempts: e.attempts,
          error: e.error,
          tabId: e.tabId ?? null,
          pageUrl: e.pageUrl ?? null
        })),
        allScanned: detectedLog.map(e => ({
          id: e.id ?? null,
          text: e.text,
          isToxic: e.isToxic,
          toxicPercentage: e.toxicPercentage ?? null,
          timestamp: e.timestamp ?? null,
          tabId: e.tabId ?? null,
          pageUrl: e.pageUrl ?? null
        }))
      });
      break;

    case "clearDetected":
      detectedLog.length = 0;
      sendResponse({ success: true });
      break;

    case "clearChanged":
      detoxLog.length = 0;
      sendResponse({ success: true });
      break;

    case "clearCaches":
      (async () => {
        try {
          classificationCache.clear();
          detoxCache.clear();
          cachesDirty = { classification: false, detox: false };
          await storageSet({ classificationCache: {}, detoxCache: {} });
          sendResponse({ success: true });
        } catch (e) {
          sendResponse({ success: false, error: String(e) });
        }
      })();
      return true;

    case "flushCaches":
      (async () => {
        try {
          await flushCachesToStorage();
          sendResponse({ success: true });
        } catch (e) {
          sendResponse({ success: false, error: String(e) });
        }
      })();
      return true;

    case "resetSettings":
      (async () => {
        try {
          const defaults = {
            TOXIC_CONFIDENCE_THRESHOLD: 99,
            BATCH_DELAY: 100,
            MAX_BATCH_SIZE: 8,
            DETOX_CONCURRENCY: 4,
            CACHE_TTL_MINUTES: 60,
            LOG_CAP: 500
          };
          await storageSet({ extSettings: defaults });
          // apply immediately
          CONFIG.TOXIC_CONFIDENCE_THRESHOLD = Number(defaults.TOXIC_CONFIDENCE_THRESHOLD);
          CONFIG.DETOX_CONCURRENCY = Number(defaults.DETOX_CONCURRENCY);
          CONFIG.LOG_CAP = Number(defaults.LOG_CAP);
          if (defaults.CACHE_TTL_MINUTES != null) {
            CACHE_TTL_MS = Number(defaults.CACHE_TTL_MINUTES) * 60 * 1000;
          }
          // flush caches after resetting
          await storageSet({ classificationCache: {}, detoxCache: {} });
          classificationCache.clear(); detoxCache.clear();
          cachesDirty = { classification: false, detox: false };
          sendResponse({ success: true });
        } catch (e) {
          sendResponse({ success: false, error: String(e) });
        }
      })();
      return true;

    case "classifyText":
      (async () => {
        try {
          if (Array.isArray(msg.texts)) {
            // classify in parallel; classifyText uses cache so repeated texts are fast
            const results = await Promise.all(msg.texts.map(classifyText));
            sendResponse({
              success: true,
              results: results.map(r => ({
                success: r.success,
                isToxic: r.success ? r.isToxic : null,
                error: r.success ? null : r.error
              }))
            });
          } else {
            const result = await classifyText(msg.text);
            sendResponse({
              success: result.success,
              isToxic: result.success ? result.isToxic : null,
              error: result.success ? null : result.error
            });
          }
        } catch (err) {
          console.error("Classification error:", err);
          sendResponse({ success: false, error: String(err) });
        }
      })();
      return true;

    case "detoxifyText":
      (async () => {
        try {
          if (Array.isArray(msg.texts)) {
            const results = await detoxifyTextBatch(msg.texts);
            sendResponse({
              success: true,
              outputs: results.map(r => r.output),
              attempts: results.map(r => r.attempts),
              errors: results.map(r => r.error)
            });
          } else {
            const res = await detoxifyTextSingle(msg.text);
            sendResponse({
              success: true,
              outputs: [res.output],
              attempts: [res.attempts],
              errors: [res.error]
            });
          }
        } catch (err) {
          console.error("Detoxify error:", err);
          sendResponse({ success: false, error: String(err) });
        }
      })();
      return true;
  }
});

// Attempt to flush caches when the service worker is suspended
try {
  if (chrome.runtime && chrome.runtime.onSuspend) {
    chrome.runtime.onSuspend.addListener(() => {
      try { flushCachesToStorage(); } catch (e) {}
    });
  }
} catch (e) {}