// UI Elements
const totalCount = document.getElementById('totalCount');
const rescanBtn = document.getElementById('rescan');
const scanStatus = document.getElementById('scanStatus');
const scannedList = document.getElementById('scanned-list');
const highlightCheckbox = document.getElementById('highlightOnPage');
const extEnabledCheckbox = document.getElementById('extEnabled');
const disableNotice = document.getElementById('disableNotice');
const restoreAllBtn = document.getElementById('restoreAll');

// Track which items currently have their original shown in the popup
const shownOriginals = new Set();

let scanInterval = 1000; // ms
let scanTimer = null;
let nextScanTime = null;

// Messaging helpers
function sendMessageToTab(msg) {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs[0]) return resolve(undefined);
      const tabId = tabs[0].id;
      chrome.tabs.sendMessage(tabId, msg, (res) => {
        if (chrome.runtime.lastError) return resolve(undefined);
        resolve(res);
      });
    });
  });
}

function sendToBackground(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      if (chrome.runtime.lastError) return resolve(undefined);
      resolve(res);
    });
  });
}

function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, function (c) {
    return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c];
  });
}

// Scan timer helpers
function updateScanStatus() {
  if (nextScanTime) {
    const ms = Math.max(0, nextScanTime - Date.now());
    scanStatus.textContent = `Rescanning ${Math.ceil(ms / 1000)}sec`;
  } else {
    scanStatus.textContent = '';
  }
}

function scheduleNextScan() {
  if (scanTimer) clearTimeout(scanTimer);
  nextScanTime = Date.now() + scanInterval;
  updateScanStatus();
  scanTimer = setTimeout(() => {
    triggerRescan();
  }, scanInterval);
}

// Render UI
async function loadAndRender() {
  const res = await sendToBackground({ type: 'getDetoxLog' });
  if (!res) return;

  const pairs = res.pairs || [];
  let scanned = res.allScanned || [];

  // Get active tab id to filter logs for the current page
  const activeTab = await new Promise((resolve) => {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        resolve((tabs && tabs[0]) || null);
      });
    } catch (e) {
      resolve(null);
    }
  });
  const activeTabId = activeTab ? activeTab.id : null;

  if (activeTabId != null) {
    scanned = scanned.filter((s) => (s.tabId == null ? false : s.tabId === activeTabId));
  }

  // Map detox outputs by id and by original text for fallback
  const detoxById = new Map();
  const detoxByText = new Map();
  for (const p of pairs) {
    if (p.id != null) detoxById.set(String(p.id), p);
    if (p.original) detoxByText.set(String(p.original), p);
  }

  totalCount.textContent = scanned.length;
  scannedList.innerHTML = '';

  const itemsWithStatus = scanned.map((item) => {
    const id = item.id != null ? String(item.id) : null;
    const text = item.text || '';
    let status = 'unclassified';
    if (item.isToxic === null || item.isToxic === undefined) status = 'unclassified';
    else if (item.isToxic === false) status = 'non-toxic';
    else if (item.isToxic === true) {
      const d = id ? detoxById.get(id) : detoxByText.get(String(text));
      if (d) {
        status = d.blocked ? 'blocked' : 'toxic';
      } else {
        status = 'ungenerated';
      }
    }
    return { item, id, text, status };
  });
  const order = { blocked: 0, toxic: 1, 'non-toxic': 2, unclassified: 3, ungenerated: 4 };
  itemsWithStatus.sort((a, b) => (order[a.status] - order[b.status]));

  for (const entry of itemsWithStatus) {
    const { item, id, text, status } = entry;
    const div = document.createElement('div');
    div.className = 'scan-item';
    div.dataset.id = id;

    const badge = document.createElement('span');
    badge.className = `status-badge status-${status}`;
    // Friendly badge label (special case for blocked)
    const labelMap = { 'toxic': 'Toxic', 'non-toxic': 'Non-toxic', 'unclassified': 'Unclassified', 'ungenerated': 'Ungenerated' };
    if (status === 'blocked') {
      badge.textContent = '●';
      badge.title = 'Blocked (made unreadable)';
      badge.classList.add('status-blocked');
    } else {
      const baseLbl = labelMap[status] || String(status).toUpperCase();
      // Add confidence percentage if available for toxic/non-toxic
      if ((status === 'toxic' || status === 'non-toxic') && item.toxicPercentage != null) {
        badge.textContent = `${baseLbl} ${item.toxicPercentage.toFixed(1)}%`;
      } else {
        badge.textContent = baseLbl;
      }
    }

    const main = document.createElement('div');
    // If toxic and we have a regenerated (detoxified) version, show altered text only by default
    if (status === 'toxic') {
      const detoxEntry = (id && detoxById.get(id)) || detoxByText.get(String(text));
      const regenDiv = document.createElement('div');
      regenDiv.className = 'regen-text';
      const regenText = (detoxEntry && detoxEntry.detoxified) || '';
      regenDiv.innerHTML = escapeHtml(regenText || '(no detox output)');

      // original hidden by default; toggled by View Original button
      const originalDiv = document.createElement('div');
      originalDiv.className = 'original-text';
      originalDiv.style.display = shownOriginals.has(id) ? '' : 'none';
      originalDiv.innerHTML = escapeHtml(text);

      main.appendChild(regenDiv);
      main.appendChild(originalDiv);
    } else if (status === 'blocked') {
      // show blocked placeholder; original hidden by default
      const blockedDiv = document.createElement('div');
      blockedDiv.className = 'blocked-note';
      blockedDiv.textContent = 'Blocked (hidden on page)';

      const originalDiv = document.createElement('div');
      originalDiv.className = 'original-text';
      originalDiv.style.display = 'none';
      originalDiv.innerHTML = escapeHtml(text);

      main.appendChild(blockedDiv);
      main.appendChild(originalDiv);

    } else {
      main.innerHTML = escapeHtml(text);
    }

    const meta = document.createElement('div');
    meta.className = 'meta';
    const ts = item.timestamp ? new Date(item.timestamp).toLocaleString() : '';
    meta.textContent = ts + (id ? ` | id: ${id}` : '');

    // Per-item buttons: View Original and Restore (for toxic/blocked only)
    const btnWrap = document.createElement('div');
    btnWrap.className = 'item-buttons';
    if (status === 'toxic' || status === 'blocked') {
      const viewBtn = document.createElement('button');
      viewBtn.className = 'clear-btn view-original';
      viewBtn.textContent = 'View Original';
      viewBtn.addEventListener('click', (ev) => {
        ev.stopPropagation();
        const orig = div.querySelector('.original-text');
        if (!orig) return;
        if (orig.style.display === 'none') {
          orig.style.display = '';
          viewBtn.textContent = 'Hide Original';
          if (id) shownOriginals.add(id);
        } else {
          orig.style.display = 'none';
          viewBtn.textContent = 'View Original';
          if (id) shownOriginals.delete(id);
        }
      });
      btnWrap.appendChild(viewBtn);

      const restoreBtn = document.createElement('button');
      restoreBtn.className = 'clear-btn restore-original';
      restoreBtn.textContent = 'Restore to original';
      restoreBtn.addEventListener('click', async (ev) => {
        ev.stopPropagation();
        if (!id) return;
        // instruct content script to restore this id
        await sendMessageToTab({ type: 'restoreOriginal', id });
        // inform background to remove/mark the detox entry so UI updates
        try { await sendToBackground({ type: 'removeDetoxEntry', id }); } catch (e) {}
        // refresh popup view
        // also clear shownOriginals for this id
        if (id) shownOriginals.delete(id);
        setTimeout(loadAndRender, 300);
      });
      btnWrap.appendChild(restoreBtn);
    }

    div.appendChild(badge);
    div.appendChild(main);
    div.appendChild(btnWrap);
    div.appendChild(meta);

    div.addEventListener('click', () => {
      if (!id) return;
      sendMessageToTab({ type: 'applyColor', id: id, status });
    });

    // Hover in popup should temporarily highlight the element on the page
    div.addEventListener('mouseenter', () => {
      if (!id) return;
      try { if (!(extEnabledCheckbox && !extEnabledCheckbox.checked)) sendMessageToTab({ type: 'highlightText', id }); } catch (e) {}
    });
    div.addEventListener('mouseleave', () => {
      if (!id) return;
      try { if (!(extEnabledCheckbox && !extEnabledCheckbox.checked)) sendMessageToTab({ type: 'removeHighlight', id }); } catch (e) {}
    });

    scannedList.appendChild(div);
  }

  // apply highlights if toggle is on
  if (highlightCheckbox.checked) {
    applyHighlightsToPage();
  }
}

// Refresh popup when the active tab changes or finishes loading
try {
  chrome.tabs.onActivated.addListener(() => {
    loadAndRender();
  });
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo && changeInfo.status === 'complete') loadAndRender();
  });
} catch (e) {
  // ignore if tabs permission not present
}

async function applyHighlightsToPage() {
  // do nothing if extension disabled
  if (extEnabledCheckbox && !extEnabledCheckbox.checked) return;
  const res = await sendToBackground({ type: 'getDetoxLog' });
  if (!res) return;
  const pairs = res.pairs || [];
  let scanned = res.allScanned || [];

  // filter to active tab
  const activeTab = await new Promise((resolve) => {
    try { chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve((tabs && tabs[0]) || null)); }
    catch (e) { resolve(null); }
  });
  const activeTabId = activeTab ? activeTab.id : null;
  if (activeTabId != null) scanned = scanned.filter(s => s.tabId === activeTabId);

  const detoxById = new Map();
  const detoxByText = new Map();
  for (const p of pairs) {
    if (p.id != null) detoxById.set(String(p.id), p);
    if (p.original) detoxByText.set(String(p.original), p);
  }

  for (const item of scanned) {
    const id = item.id != null ? String(item.id) : null;
    if (!id) continue;

    let status = 'unclassified';
    if (item.isToxic === null || item.isToxic === undefined) status = 'unclassified';
    else if (item.isToxic === false) status = 'non-toxic';
    else if (item.isToxic === true) {
      const d = detoxById.get(id) || detoxByText.get(String(item.text));
      if (d) {
        status = d.blocked ? 'blocked' : 'toxic';
      } else {
        status = 'ungenerated';
      }
    }

    await sendMessageToTab({ type: 'applyColor', id, status });
  }
}

async function clearHighlightsOnPage() {
  const res = await sendToBackground({ type: 'getDetoxLog' });
  if (!res) return;
  let scanned = res.allScanned || [];
  const activeTab = await new Promise((resolve) => {
    try { chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve((tabs && tabs[0]) || null)); }
    catch (e) { resolve(null); }
  });
  const activeTabId = activeTab ? activeTab.id : null;
  if (activeTabId != null) scanned = scanned.filter(s => s.tabId === activeTabId);
  for (const item of scanned) {
    const id = item.id != null ? String(item.id) : null;
    if (!id) continue;
    await sendMessageToTab({ type: 'removeColor', id });
  }
}

async function triggerRescan() {
  scanStatus.textContent = 'Rescanning...';
  await sendMessageToTab({ type: 'triggerRescan' });
  setTimeout(loadAndRender, 500);
  scheduleNextScan();
}

rescanBtn.addEventListener('click', () => {
  triggerRescan();
});

highlightCheckbox.addEventListener('change', () => {
  if (extEnabledCheckbox && !extEnabledCheckbox.checked) {
    // do not allow highlights when extension disabled
    highlightCheckbox.checked = false;
    return;
  }
  if (highlightCheckbox.checked) applyHighlightsToPage();
  else clearHighlightsOnPage();
});

// Open advanced settings page
const openSettingsBtn = document.getElementById('openSettings');
if (openSettingsBtn) {
  openSettingsBtn.addEventListener('click', () => {
    try {
      const url = chrome.runtime.getURL('settings.html');
      chrome.tabs.create({ url });
    } catch (e) {
      // fallback: open in same popup (not ideal)
      window.open('settings.html', '_blank');
    }
  });
}

// Handle extension enabled toggle
if (extEnabledCheckbox) {
  // initialize from storage
  chrome.storage.local.get(['extSettings'], (res) => {
    const s = res?.extSettings || {};
    if (s.enabled === false) extEnabledCheckbox.checked = false;
    else extEnabledCheckbox.checked = true;
  });

  // reflect notice visibility
  if (extEnabledCheckbox.checked) disableNotice.style.display = 'none';
  else disableNotice.style.display = '';

  extEnabledCheckbox.addEventListener('change', async () => {
    const enabled = !!extEnabledCheckbox.checked;
    // persist setting
    try {
      const cur = (await sendToBackground({ type: 'noop_get_settings' })) || {};
    } catch (e) {}
    const s = await new Promise((resolve) => chrome.storage.local.get(['extSettings'], (r) => resolve(r?.extSettings || {})));
    s.enabled = enabled;
    chrome.storage.local.set({ extSettings: s }, () => {});

    // notify content script in active tab to either restore or allow behavior
    await sendMessageToTab({ type: 'extensionEnabled', enabled });

    if (!enabled) {
      // advise reload for full restore
      disableNotice.style.display = '';
      // attempt to restore elements right away
      await sendMessageToTab({ type: 'restoreAll' });
    } else {
      disableNotice.style.display = 'none';
      // trigger a rescan so extension behavior resumes
      await sendMessageToTab({ type: 'triggerRescan' });
    }

    // Reload all http(s) tabs so page-level DOM artifacts are cleared or re-applied
    try {
      chrome.tabs.query({}, (tabs) => {
        for (const t of (tabs || [])) {
          try {
            const url = t.url || '';
            if (/^https?:\/\//i.test(url)) {
              try { chrome.tabs.reload(t.id); } catch (e) {}
            }
          } catch (e) {}
        }
      });
    } catch (e) {}
    // refresh popup
    setTimeout(loadAndRender, 300);
  });
}

// Restore All button behavior - restores all items on active tab and clears background entries
if (restoreAllBtn) {
  restoreAllBtn.addEventListener('click', async () => {
    // get active tab id
    const activeTab = await new Promise((resolve) => {
      try { chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => resolve((tabs && tabs[0]) || null)); }
      catch (e) { resolve(null); }
    });
    const tabId = activeTab ? activeTab.id : null;

    // instruct content script to restore elements on the page
    await sendMessageToTab({ type: 'restoreAll' });

    // ask background to remove detox entries for this tab so popup UI refreshes
    if (tabId != null) {
      try { await sendToBackground({ type: 'removeDetoxEntriesForTab', tabId }); } catch (e) {}
    }

    // refresh popup
    setTimeout(loadAndRender, 300);
  });
}

// Initial load
loadAndRender();
scheduleNextScan();

// Update scan status every 200ms
setInterval(updateScanStatus, 200);
 
// Sync highlight checkbox with page state on open
async function syncHighlightToggle() {
  try {
    const state = await sendMessageToTab({ type: 'checkHighlights' });
    if (state && typeof state.hasHighlights === 'boolean') {
      highlightCheckbox.checked = state.hasHighlights;
    }
  } catch (e) {
    // ignore
  }
}

// Initialize highlight checkbox state and ensure toggle behavior is safe
syncHighlightToggle();

// Wrap toggle with disable while applying to avoid double-click issues
highlightCheckbox.addEventListener('change', async () => {
  highlightCheckbox.disabled = true;
  try {
    if (highlightCheckbox.checked) await applyHighlightsToPage();
    else await clearHighlightsOnPage();
  } catch (e) {}
  highlightCheckbox.disabled = false;
});